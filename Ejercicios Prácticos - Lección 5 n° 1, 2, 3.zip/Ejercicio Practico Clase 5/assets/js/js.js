const button = document.getElementById('boton');
button.addEventListener('click', function() {
    console.log('has hecho click en el boton')
});

//const colorButton = document.getElementById('colorBoton');
//colorButton.addEventListener('click', function(){
    //document.body.style.backgroundColor = 'lightblue'
//});
